/**
 * Template Name
 * @Owner Your Name or Company
 * @Date 2023-04-12
 */

import { Creative } from "./Creative.js";
import { createCube } from "./creative-cube-plugin.js";
import { plugins } from "./plugins.js";

// Set values from LemonPI Manage-r
export function initCreative(content) {
	//#region SET DYNAMIC FALLBACK
	if (content.fallbackImage && content.fallbackImage.value)
		$(".fallback").css({
			"background-image": `url(${content.fallbackImage.value})`,
			"background-size": "cover",
		});

	$(".fallback").click(() =>
		window.dispatchEvent(
			new CustomEvent("lemonpi.interaction/click", {
				detail: {
					placeholder: "fallbackUrl",
				},
			})
		)
	);
	//#endregion END OF FALLBACK
	gsap.to("#creative_container", { duration: 0, autoAlpha: 1 });
	//#region VARS AND SETTINGS
	let finalCubes = [];

	const introAnimation = gsap.timeline({
		onStart: () => {
			$(".cubeContainer").css("pointer-events", "none");
		},
		onComplete: () => {
			$(".cubeContainer").css("pointer-events", "inherit");
		},
	});

	const attentionAnimationTimeline = gsap.timeline({
		paused: true,
		repeat: -1,
		repeatDelay: 2.5,
	});
	const ctaCopy = content.ctaCopy.value;
	$("#cta").html(ctaCopy);
	$("#logo").attr("src", content.logo.value);

	// FILTER CONTENT ON CUBES
	const cubes = Object.keys(content)
		.filter((key) => key.includes("cube"))
		.reduce((cur, key) => {
			return Object.assign(cur, { [key]: content[key] });
		}, {});

	// CREATE CUBECONTAINER FOR EACH CUBE AND REMOVE TEMPLATE
	Object.keys(cubes).forEach((key, index) => {
		$("#cubeContainerTemplate")
			.clone()
			.appendTo(".mainCubeContainer")
			.attr("class", `cubeContainer`)
			.attr("id", `cubeContainer${index}`);

		$(`#cubeContainer${index}`).find("#cube").attr("id", `cube${index}`);
	});

	$("#cubeContainerTemplate").remove();

	//#endregion END OF VARS AND SETTINGS

	//#region FUNCTIONS
	const clickOut = () => {
		window.dispatchEvent(
			new CustomEvent("lemonpi.interaction/click", {
				detail: {
					placeholder: "clickOut",
					query: {},
				},
			})
		);
	};

	const createVideo = (videoUrl, videoStillUrl, id, className, container) => {
		const video = $("<video>", {
			id: id || "video",
			class: className || "video",
			src: videoUrl,
		})
			.prop("muted", true)
			.prop("playsinline", true)
			.attr("muted", true)
			.attr("playsinline", true)
			.attr("loop", "loop")
			.get(0);

		const videoStill = $("<img>", {
			alt: id ? id + "Still" : "videoStill",
			id: id ? id + "Still" : "videoStill",
			class: className ? className + "Still" : "videoStill",
			src: videoStillUrl,
		});

		video
			.play()
			.then(() => {
				$(container).append(video);
			})
			.catch((error) => {
				preloadImage(videoStill, () => {
					$(container).append(videoStill);
				});
			});

		function preloadImage(element, callback) {
			if (!element) throw "Error: could not load image";
			element.get(0).onload = callback();
		}

		return { video, videoStill };
	};
	// CREATE CUBE FACES, ON COMPLETE CREATE CUBE
	Object.keys(cubes).forEach((key, index) => {
		createCubeFaces(cubes[`cube${index + 1}`].value, index, createCubeFunction);
	});

	function createCubeFaces(cubeContent, cubeIndex, callback) {
		const originalFace = $(`#cube${cubeIndex}`).find("#cubeFaceTemplate");

		cubeContent.forEach((face, index, array) => {
			const newFace = originalFace
				.clone()
				.attr("id", `cubeFace${cubeIndex}_${index}`);
			$(`#cube${cubeIndex}`).append(newFace);

			// Delete the first cloned face
			if (index === array.length - 1) originalFace.remove();
			if (face["bgImage"].value)
				$(`#cubeFace${cubeIndex}_${index}`)
					.find(".image")
					.css({
						background: `url(${face["bgImage"].value})`,
						backgroundSize: "cover",
						backgroundRepeat: "no-repeat",
					});

			if (face["bgVideo"].value) {
				// Usage example
				createVideo(
					face["bgVideo"].value,
					face["videoStill"].value,
					"video",
					"video",
					$(`#cubeFace${cubeIndex}_${index}`).find(".videoContainer")
				);
			}

			if (face["copy"].value) {
				$(`#cubeFace${cubeIndex}_${index}`)
					.find(".copy")
					.append(face["copy"].value);
			}

			if (face["copyColor"].value) {
				$(`#cubeFace${cubeIndex}_${index}`)
					.find(".copy")
					.css("color", face["copyColor"].value);
			}

			if (face["copyBgColor"].value) {
				$(`#cubeFace${cubeIndex}_${index}`)
					.find(".copyContainer")
					.css("background", face["copyBgColor"].value);
			}
		});

		callback(`#cubeContainer${cubeIndex}`, cubeIndex);
	}

	// CREATE THE CUBE
	function createCubeFunction(container, index) {
		finalCubes.push(
			createCube(container, {
				id: `cube${index}`,
				animationEase: "elastic.out(1, 0.75)",
				animationDuration: 1,
				perspectiveFactor: [1.5],
				liveDrag: true,
				threshold: 0.01,
				direction: "x",
			})
		);
	}

	const playAttentionAnimation = () => {
		new TimelineMax()
			.to("#cta", 0.1, { y: -5 })
			.to("#cta", 1, { y: 0, ease: Elastic.easeOut });
	};

	const onUserEnter = () => {
		attentionAnimationTimeline.repeat(0).pause();
		attentionAnimation.pause();
		$("video").each(function () {
			this.play();
		});
	};
	const onUserLeave = () => {
		gsap.delayedCall(15, function () {
			$("video").each(function () {
				this.pause();
			});
		});
		attentionAnimation.play();
	};

	const cubeEnter = (e) => {
		$(e).css("z-index", 10);
		gsap.to(".copy", 1, { z: 50 });
	};

	const cubeLeave = (e) => {
		$(e).css("z-index", 1);
		gsap.to(".copy", 1, { z: 0 });
	};

	const loopStop = () => {
		//console.log("kill animations");
		$("video").each(function () {
			this.pause();
		});
		attentionAnimation.kill();
		attentionAnimationTimeline.repeat(0);
	};

	//#endregion END OF FUNCTIONS

	//#region ANIMATIONS
	attentionAnimationTimeline
		// .add(() => console.log(myCube.cube))
		// .add(() => myCube.disableInteraction())
		.add(gsap.to("#swipeIndicator", { opacity: 1, duration: 0.25 }))
		.add(
			gsap.to("#swipeIndicator", {
				x: -100,
				duration: 0.5,
				ease: "power2.inOut",
			})
		)
		.add(gsap.to("#swipeIndicator", { opacity: 0, duration: 0.25 }))
		.add(() => finalCubes[0].nextFace(), "-=0.5")
		.add(gsap.to({}, {}));

	const attentionAnimation = gsap
		.timeline({ repeat: -1 })
		.add(playAttentionAnimation, 3);

	introAnimation.staggerFrom(
		".cube",
		3,
		{
			rotationY: function (index) {
				return index % 2 === 0 ? 90 : -90;
			},
			scale: 0.7,
			ease: "elastic.out(1,0.5)",
		},
		0
	);

	// Start de timeline

	const mainTimeline = gsap
		.timeline()
		.add(introAnimation, 0)
		.add(attentionAnimation, 1)
		.add(() => attentionAnimationTimeline.play().delay(2.5), 0.5);

	//#endregion END OF ANIMATIONS

	//#region EVENTLISTENERS
	$("#creative_container")
		.on("mouseenter touchstart", onUserEnter)
		.on("mouseleave touchend", onUserLeave);

	$(".cubeContainer")
		.on("mouseenter touchstart", function (e) {
			cubeEnter(this);
		})
		.on("mouseleave touchend", function (e) {
			cubeLeave(this);
		});

	document.addEventListener("cubeIndexUpdate", (e) => {
		let currentIndex = e.detail.currentIndex;
		if (
			$(e.detail.cubeSettings.faces[currentIndex]).find(".video").length > 0
		) {
			$(e.detail.cubeSettings.faces[currentIndex]).find(
				".video"
			)[0].currentTime = 0;
			$(e.detail.cubeSettings.faces[currentIndex]).find(".video")[0].play();
			$(e.detail.cubeSettings.faces[currentIndex]).find(".video");
		}
	});

	//#endregion END OF EVENTLISTENERS

	//#region OTHER
	gsap.delayedCall(15, loopStop);
	//#endregion END OF OTHER
}
