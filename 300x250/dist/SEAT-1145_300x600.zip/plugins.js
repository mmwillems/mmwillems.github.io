// @ts-nocheck
/* eslint-disable */
import { initCreative } from "./script.js";

/**
 * Lemonpi Boilerplate for plugin management in creative libraries
 * This implementation is 'borrowed' from Lemonpi studio
 * @owner: Bram Korsten
 * @date: September 12 2022
 */

// List of all the installed plugins.
// This is managed by the boilerplate extension.
// DO NOT MODIFY
var pluginSource = [
	/* @plugins */
	{
		name: "ghg",
		init: function () {
			return (function (a) {
				function t() {
					window.addEventListener("message", function (e) {
						var n;
						e.data &&
							"LP_EXEC_SCRIPT_RESPONSE" === e.data.name &&
							(((n = document.createElement("script")).text = e.data.script),
							document.body.appendChild(n));
					});
				}
				function r(e) {
					if (i && window.lemonpi.context) {
						var n = e.replace(/\$\{/, "").replace(/\}/, "").trim();
						return i[n];
					}
					return e;
				}
				function c() {
					if (w) return !0;
					if (m && void 0 !== a.looping) return a.looping;
					if (f) return !1;
					var e = parseInt(r("${SELLER_MEMBER_ID}"), 10) || 1;
					return 0 < e && 181 !== e && 280 !== e;
				}
				function s(o) {
					var i;
					void 0 !== window.lemonpi &&
						((i = function (e) {
							for (var n in e)
								Object.prototype.hasOwnProperty.call(e, n) &&
									"delay" !== n &&
									$(n).css(e[n]);
						}),
						window.lemonpi.subscribe(function (e) {
							e = e && e.cssOverride && e.cssOverride.value;
							if (e)
								try {
									var n = JSON.parse(e),
										t = void 0 !== o ? o : n.delay;
									t
										? setTimeout(function () {
												return i(n);
										  }, JSON.parse(t))
										: i(n);
								} catch (e) {
									f && console.warn("Syntax error in cssOverride JSON", e);
								}
						}));
				}
				function d(e) {
					var n;
					void 0 !== window.lemonpi &&
						((n = document.querySelector("#creative_container")),
						((e = e).referer = r("${REFERER_URL_ENC}")),
						(e.creativeIsVisible = !!(
							n.offsetWidth ||
							n.offsetHeight ||
							n.getClientRects().length
						)),
						window.postMessage(e, "*"),
						window.parent.postMessage(e, "*"));
				}
				function l() {
					var n;
					e &&
						(n = setInterval(function () {
							var t, o, e;
							0 !== window.clickTag1.length &&
								(clearInterval(n),
								2 < (e = window.clickTag1.split("__AN_MACROS__")).length &&
									(e.pop(),
									e.shift(),
									(t = e.map(function (e) {
										e = e.split(":");
										return { macro: e[0], value: e[1] || "0" };
									})),
									"undefined" != typeof lemonpi &&
										void 0 !== lemonpi.context &&
										((o = window.open),
										(window.open = function (e) {
											for (
												var n =
													e.split("3D__AN_MACROS__")[0] +
													"3D" +
													("h" + e.split("__AN_MACROS__h")[1]);
												0 < t.length;

											)
												n = (n = n.replace(
													"(%253A" + t[0].macro + "%253A)",
													t[0].value
												)).replace("(%3A" + t[0].macro + "%3A)", t[0].value);
											o.call(window, n);
										}))));
						}, 100));
				}
				function p() {
					document.hidden || "function" != typeof window.onPageVisible
						? document.hidden &&
						  "function" == typeof window.onPageHidden &&
						  window.onPageHidden()
						: window.onPageVisible();
				}
				function o() {
					d({ name: "LEMONPI_CREATIVE_WILL_LOAD" });
				}
				var u = void 0,
					w = !1,
					m = "4005" === window.location.port,
					f =
						m ||
						-1 < window.location.hostname.indexOf("lemonpi.io") ||
						/lemonpi-prod-templates\.s3\.amazonaws\.com/.test(
							window.location.host
						),
					e = "string" == typeof clickTag1,
					i = void 0;
				return {
					creativeWillLoad: function (n) {
						window.lemonpi.context
							? window.lemonpi.context.subscribe(function (e) {
									(i = e.appnexus), t(), o(), n();
							  })
							: (t(), o(), n()),
							window.lemonpi.config && window.lemonpi.config.subscribe(d);
					},
					creativeDidRender: function () {
						var e, t, n, o, i;
						(-1 < window.location.href.indexOf("inapptesting=1") ||
							(!f &&
								void 0 !== window.screenad &&
								!window.screenad.isPreviewer)) &&
							(console.log = function (e) {
								d({ name: "LEMONPI_LOG", message: e });
							}),
							!m &&
								window.Raven &&
								"function" == typeof window.Raven.config &&
								window.Raven.config(
									"https://87dc5e0450d3461f83c185097b7db5cf@sentry.io/75086"
								).install(),
							s(),
							new URLSearchParams(window.location.search).has("inapptesting") ||
								(window.addEventListener("message", function (e) {
									e.data &&
										"LP_IS_IN_APP" === e.data.name &&
										(window.open = function (e) {
											e = { name: "LP_MRAID_CLICK", url: e };
											window.parent.postMessage(e, "*"),
												window.postMessage(e, "*");
										});
								}),
								(n = { name: "LP_REQUEST_IN_APP" }),
								window.parent.postMessage(n, "*"),
								window.postMessage(n, "*")),
							l(),
							(e = document.querySelector("head")),
							((n = document.createElement("style")).type = "text/css"),
							n.appendChild(
								document.createTextNode(
									"* { box-sizing: border-box; } #creative_container { cursor: pointer; -webkit-text-size-adjust: 100%; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; -webkit-tap-highlight-color: rgba(0,0,0,0); -webkit-tap-highlight-color: transparent; -ms-user-select: none; -moz-user-select: none; -webkit-user-select: none; user-select: none }"
								)
							),
							e.appendChild(n),
							document
								.getElementById("creative_container")
								.addEventListener("mouseenter", function () {
									u = setTimeout(function () {
										w = !0;
									}, 1e3);
								}),
							document
								.getElementById("creative_container")
								.addEventListener("mouseleave", function () {
									clearTimeout(u);
								}),
							(t = setInterval(function () {
								var e = void 0,
									n = Math.abs(parseInt(a.loopstopDelay, 10)),
									e = isNaN(n) || 0 === n ? 15 : n;
								"function" != typeof window.onLoopStop ||
									(c() && !window.screenad) ||
									(clearInterval(t),
									TweenMax.delayedCall(e, function () {
										window.onLoopStop();
									}));
							}, 100)),
							setTimeout(function () {
								return clearInterval(t);
							}, 500),
							(n = document
								.querySelector('meta[name="ad.size"]')
								.content.match(/\d+/g)),
							(o = { "336x280": 0.8928571429, "1272x328": 0.7625786164 }[
								n[0] + "x" + n[1]
							]),
							m &&
								a.previewScalifier &&
								o &&
								window.addEventListener("message", function (e) {
									e.data &&
										"LEMONPI_CREATIVE_RENDERED" === e.data.name &&
										(((e = document.querySelector(
											"#creative_container"
										)).style.transformOrigin = "0 0"),
										(e.style.webkitTransformOrigin = "0 0"),
										(e.style.transform = "scale(" + o + ")"),
										(e.style.webkitTransform = "scale(" + o + ")"));
								}),
							void 0 !== document.hidden &&
								document.addEventListener("visibilitychange", p, !1),
							(i = lemonpi.click),
							(window.lemonpi.click = function (e, n, t) {
								d({ name: "LP_CLICK" }), i(e, n, t);
							}),
							f &&
								$.getScript(
									"https://s3.eu-central-1.amazonaws.com/ghg-tools/ghg-banner-basics-debugger/debugger-v2.js",
									function () {
										var e, n;
										m &&
											((e = window.location.href.replace(
												"concept.html",
												"script.js"
											)),
											(n = new XMLHttpRequest()).addEventListener(
												"load",
												function (e) {
													e = e.currentTarget.responseText.match(
														/function executeScript\(plugins\) {[^]+?(?=\/\/ All the Creative's plugins.)/g
													);
													(e = e ? e[0] : "").match(/https?/gi) &&
														window.drawWarning(
															"error",
															"Found one or more hardcoded URL's in your creative, please move them to a placeholder."
														);
												}
											),
											n.open("get", e, !0),
											n.send());
									}
								),
							setTimeout(function () {
								var e = {
									name: "LEMONPI_CREATIVE_RENDERED",
									supplyType: r("${SUPPLY_TYPE}"),
									mraidVersion:
										"undefined" != typeof mraid
											? window.mraid.getVersion()
											: "n/a",
									appId: r("${EXT_APP_ID}"),
								};
								d(Object.assign(e));
							}, 1);
					},
					pluginApi: {
						getAppNexusMacro: r,
						getAllowLooping: c,
						getUserInteracted: function () {
							return w;
						},
						addMacrosToUrl: function (e) {
							return e
								.replace("${CREATIVE_ID}", r("${CREATIVE_ID}"))
								.replace("${USER_ID}", r("${USER_ID}"))
								.replace("${AUCTION_ID}", r("${AUCTION_ID}"))
								.replace("${CREATIVE_SIZE}", r("${CREATIVE_SIZE}"));
						},
						isInLemonpiStudio: m,
						isInAnyLemonpiEnvironment: f,
						getResizedImageUrl: function (e, n, t, o, i) {
							var a =
									"https://image.lemonpi.io/img/http://res.cloudinary.com/" +
									e +
									"/image/fetch/",
								e = "c_scale";
							return (
								t && (e += ",w_" + Math.round(parseFloat(t))),
								o && (e += ",h_" + Math.round(parseFloat(o))),
								i && (e += "/q_" + i),
								a +
									e +
									"/" +
									n.replace(/^(https?:)?\/\/image\.lemonpi\.io\/img\//i, "")
							);
						},
						cssOverride: s,
					},
				};
			})({ looping: false, previewScalifier: false, loopstopDelay: "15" });
		},
	},
	{
		name: "check",
		init: function () {
			return (function (e) {
				function i() {
					return !0;
				}
				function n() {
					return !1;
				}
				var r = e;
				"4005" !== window.location.port && (r = void 0);
				var o = navigator,
					t = o.userAgent,
					a = o.standalone,
					s = {
						retina: function () {
							return (
								(window.matchMedia &&
									(window.matchMedia(
										"only screen and (min-resolution: 192dpi), only screen and (min-resolution: 2dppx), only screen and (min-resolution: 75.6dpcm)"
									).matches ||
										window.matchMedia(
											"only screen and (-webkit-min-device-pixel-ratio: 2), only screen and (-o-min-device-pixel-ratio: 2/1), only screen and (min--moz-device-pixel-ratio: 2), only screen and (min-device-pixel-ratio: 2)"
										).matches)) ||
								(window.devicePixelRatio && 2 <= window.devicePixelRatio)
							);
						},
						desktop: function () {
							return !this.mobile();
						},
						mobile: function () {
							return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
								t
							);
						},
						osx: function () {
							return /OS X/i.test(t);
						},
						windows: function () {
							return /Windows/i.test(t);
						},
						ios: function () {
							return /iPhone|iPad|iPod/i.test(t);
						},
						android: function () {
							return /Android/i.test(t);
						},
						ie: function () {
							return /MSIE|Trident/i.test(t);
						},
						ie9: function () {
							return /MSIE 9\./i.test(t);
						},
						ie10: function () {
							return /MSIE 10\./i.test(t);
						},
						ie11: function () {
							return /Trident\//i.test(t) && !/MSIE/i.test(t);
						},
						edge: function () {
							return /Edge\//i.test(t);
						},
						chrome: function () {
							return /Chrome\//i.test(t) && !/Edge\//i.test(t);
						},
						firefox: function () {
							return /Firefox\//i.test(t);
						},
						safari: function () {
							return (
								/Safari\//i.test(t) &&
								!/Chrome\//i.test(t) &&
								!/Edge\//i.test(t)
							);
						},
						inApp: function () {
							if (!this.mobile) return !1;
							if (this.ios()) {
								if (!a && !this.safari()) return !0;
							} else if (this.android())
								return /; wv|version\/[0-9]+\.[0-9]+/gi.test(t);
							return !1;
						},
					};
				if (r && void 0 !== r.deviceType)
					switch (r.deviceType) {
						case "desktop":
							(s.desktop = i), (s.mobile = n), (s.inApp = n);
							break;
						case "mobile":
							(s.desktop = n), (s.mobile = i), (s.inApp = n);
							break;
						case "in-app":
							(s.desktop = n), (s.mobile = i), (s.inApp = i);
							break;
						default:
							(s.desktop = i), (s.mobile = n), (s.inApp = n);
					}
				if (r && void 0 !== r.operatingSystem)
					switch (r.operatingSystem) {
						case "osx":
							(s.osx = i), (s.windows = n), (s.android = n), (s.ios = n);
							break;
						case "windows":
							(s.osx = n), (s.windows = i), (s.android = n), (s.ios = n);
							break;
						case "android":
							(s.osx = n), (s.windows = n), (s.android = i), (s.ios = n);
							break;
						case "ios":
							(s.osx = n), (s.windows = n), (s.android = n), (s.ios = i);
							break;
						default:
							(s.osx = n), (s.windows = n), (s.android = n), (s.ios = n);
					}
				if (r && void 0 !== r.browser)
					switch (r.browser) {
						case "chrome":
							(s.chrome = i),
								(s.safari = n),
								(s.firefox = n),
								(s.ie = n),
								(s.ie9 = n),
								(s.ie10 = n),
								(s.ie11 = n),
								(s.edge = n);
							break;
						case "safari":
							(s.chrome = n),
								(s.safari = i),
								(s.firefox = n),
								(s.ie = n),
								(s.ie9 = n),
								(s.ie10 = n),
								(s.ie11 = n),
								(s.edge = n);
							break;
						case "firefox":
							(s.chrome = n),
								(s.safari = n),
								(s.firefox = i),
								(s.ie = n),
								(s.ie9 = n),
								(s.ie10 = n),
								(s.ie11 = n),
								(s.edge = n);
							break;
						case "ie9":
							(s.chrome = n),
								(s.safari = n),
								(s.firefox = n),
								(s.ie = i),
								(s.ie9 = i),
								(s.ie10 = n),
								(s.ie11 = n),
								(s.edge = n);
							break;
						case "ie10":
							(s.chrome = n),
								(s.safari = n),
								(s.firefox = n),
								(s.ie = i),
								(s.ie9 = n),
								(s.ie10 = i),
								(s.ie11 = n),
								(s.edge = n);
							break;
						case "ie11":
							(s.chrome = n),
								(s.safari = n),
								(s.firefox = n),
								(s.ie = i),
								(s.ie9 = n),
								(s.ie10 = n),
								(s.ie11 = i),
								(s.edge = n);
							break;
						case "edge":
							(s.chrome = n),
								(s.safari = n),
								(s.firefox = n),
								(s.ie = n),
								(s.ie9 = n),
								(s.ie10 = n),
								(s.ie11 = n),
								(s.edge = i);
							break;
						default:
							(s.chrome = n),
								(s.safari = n),
								(s.firefox = n),
								(s.ie = n),
								(s.ie9 = n),
								(s.ie10 = n),
								(s.ie11 = n),
								(s.edge = n);
					}
				if (r && void 0 !== r.screenType)
					switch (r.screenType) {
						case "nonretina":
							s.retina = n;
							break;
						case "retina":
						default:
							s.retina = i;
					}
				return { pluginApi: s };
			})({
				deviceType: false,
				operatingSystem: false,
				screenType: false,
				browser: false,
			});
		},
	},

	/* @plugins-end */
];

// Setup all the handlers for different callbacks within the plugins
var creativeWillLoadHandlers = [];
var creativeDidLoadHandlers = [];
var creativeWillRenderHandlers = [];
var creativeDidRenderHandlers = [];
var creativeWillOpenClickUrlHandlers = [];
var creativeDidOpenClickUrlHandlers = [];
var layerWillRenderHandlers = {};
var layerDidRenderHandlers = {};

// initialize all registered plugins, Collect all their callbacks and hooks
// In this implementation, all plugins are kicked off before the dynamic data is loaded
var pluginApis = {};
export var plugins = {};
for (var i = 0; i < pluginSource.length; i++) {
	var plugin = pluginSource[i];
	var instance = plugin.init() || {};

	instance.creativeWillLoad &&
		creativeWillLoadHandlers.push(instance.creativeWillLoad);
	instance.creativeDidLoad &&
		creativeDidLoadHandlers.push(instance.creativeDidLoad);
	instance.creativeWillRender &&
		creativeWillRenderHandlers.push(instance.creativeWillRender);
	instance.creativeDidRender &&
		creativeDidRenderHandlers.push(instance.creativeDidRender);
	instance.creativeWillOpenClickUrl &&
		creativeWillOpenClickUrlHandlers.push(instance.creativeWillOpenClickUrl);
	instance.creativeDidOpenClickUrl &&
		creativeDidOpenClickUrlHandlers.push(instance.creativeDidOpenClickUrl);
	instance.layerWillRender &&
		addLayerHandlers(
			plugin.name,
			instance.layerWillRender,
			layerWillRenderHandlers
		);
	instance.layerDidRender &&
		addLayerHandlers(
			plugin.name,
			instance.layerDidRender,
			layerDidRenderHandlers
		);

	plugins[plugin.name] = instance.pluginApi || {};
}

// Start loading plugins (allowing plugins to load async data)
var pluginsLoading = 0;
var pluginsLoadingDone = function () {};
for (var i = 0; i < creativeWillLoadHandlers.length; i++) {
	var creativeWillLoadHandler = creativeWillLoadHandlers[i];
	if (creativeWillLoadHandler.length > 0) {
		pluginsLoading++;
		creativeWillLoadHandler(function () {
			pluginsLoading--;
			if (pluginsLoading === 0) {
				pluginsLoadingDone();
			}
		});
	} else {
		creativeWillLoadHandler();
	}
}

// Utility function that calls the callback as soon as all plugins are done loading
function awaitPlugins(callback) {
	if (pluginsLoading === 0) {
		callback();
		return;
	}

	pluginsLoadingDone = function () {
		callback();
	};
}

// Utility function to add keyed handlers (used for behaviours)
function addLayerHandlers(name, handlers, target) {
	for (var key in handlers) {
		if (handlers.hasOwnProperty(key)) {
			var newKey = name + "." + key;
			target[newKey] = handlers[key];
		}
	}
}

// Utility function that calls all passed layer handlers
function callLayerHandlers(handlers) {
	for (var key in handlers) {
		if (handlers.hasOwnProperty(key)) {
			var elements = document.querySelectorAll(
				"[data-studio-behaviour='" + key + "']"
			);

			for (var i = 0; i < elements.length; i++) {
				handlers[key](elements[i]);
			}
		}
	}
}

var content = {};

// Wait for all plugins to be done loading
awaitPlugins(function () {
	// Notify plugins that the Creative is done loading
	for (var i = 0; i < creativeDidLoadHandlers.length; i++) {
		creativeDidLoadHandlers[i]();
	}

	// Notify plugins that the Creative will start rendering
	for (var i = 0; i < creativeWillRenderHandlers.length; i++) {
		creativeWillRenderHandlers[i]();
	}

	// Notify plugins that layers will start rendering
	callLayerHandlers(layerWillRenderHandlers);

	var started = false;

	pluginApis = plugins; // Support older versions

	lemonpi.subscribe(function (cont) {
		if (started) {
			return;
		}
		started = true;

		content = cont;

		// Render (show) the Creative
		document.querySelector("#creative_container").style.display = "";

		// Notify plugins that layers are done rendering
		callLayerHandlers(layerDidRenderHandlers);

		// Notify plugins that the Creative is done rendering
		for (var i = 0; i < creativeDidRenderHandlers.length; i++) {
			creativeDidRenderHandlers[i]();
		}

		// Eval the user script, pass in the plugin APIs.
		// Evalled on the next animation frame to ensure the
		// repaint caused by making the '#creative_container' visible
		// has finished.
		window.requestAnimationFrame(function () {
			var initInterval = setInterval(function () {
				if (typeof initCreative === "function") {
					clearInterval(initInterval);
					initCreative(content);
				}
			}, 10);
		});
	});
});
